--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 15.2
-- Dumped by pg_dump version 15.2

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE ava;
--
-- Name: ava; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE ava WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'C';


ALTER DATABASE ava OWNER TO postgres;

\connect ava

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: pg_database_owner
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO pg_database_owner;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: pg_database_owner
--

COMMENT ON SCHEMA public IS 'standard public schema';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: 2015; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."2015" (
    country character varying(50),
    region character varying(50),
    "Happiness Rank" integer,
    "Happiness Score" real,
    "Standard Error" real,
    "Economy (GDP per Capita)" real,
    "Family" real,
    "Health (Life Expectancy)" real,
    freedom real,
    "Trust (Government Corruption)" real,
    generosity real,
    "Dystopia Residual" real
);


ALTER TABLE public."2015" OWNER TO postgres;

--
-- Name: 2016; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."2016" (
    country character varying(50),
    region character varying(50),
    "Happiness Rank" integer,
    "Happiness Score" real,
    "Lower Confidence Interval" real,
    "Upper Confidence Interval" real,
    "Economy (GDP per Capita)" real,
    "Family" real,
    "Health (Life Expectancy)" real,
    freedom real,
    "Trust (Government Corruption)" real,
    generosity real,
    "Dystopia Residual" real
);


ALTER TABLE public."2016" OWNER TO postgres;

--
-- Name: 2017; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."2017" (
    country character varying(50),
    "Happiness.Rank" integer,
    "Happiness.Score" real,
    "Whisker.high" real,
    "Whisker.low" real,
    "Economy..GDP.per.Capita." real,
    "Family" real,
    "Health..Life.Expectancy." real,
    freedom real,
    generosity real,
    "Trust..Government.Corruption." real,
    "Dystopia.Residual" real
);


ALTER TABLE public."2017" OWNER TO postgres;

--
-- Name: 2018; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."2018" (
    "Overall rank" integer,
    "Country or region" character varying(50),
    score real,
    "GDP per capita" real,
    "Social support" real,
    "Healthy life expectancy" real,
    "Freedom to make life choices" real,
    generosity real,
    "Perceptions of corruption" character varying(50)
);


ALTER TABLE public."2018" OWNER TO postgres;

--
-- Name: 2019; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."2019" (
    "Overall rank" integer,
    country character varying(50),
    score real,
    "GDP per capita" real,
    "Social support" real,
    "Healthy life expectancy" real,
    "Freedom to make life choices" real,
    generosity real,
    "Perceptions of corruption" real
);


ALTER TABLE public."2019" OWNER TO postgres;

--
-- Name: 2020; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."2020" (
    country character varying(50),
    "Regional indicator" character varying(50),
    "Ladder score" real,
    "Standard error of ladder score" real,
    upperwhisker real,
    lowerwhisker real,
    "Logged GDP per capita" real,
    "Social support" real,
    "Healthy life expectancy" real,
    "Freedom to make life choices" real,
    generosity real,
    "Perceptions of corruption" real,
    "Ladder score in Dystopia" real,
    "Explained by: Log GDP per capita" real,
    "Explained by: Social support" real,
    "Explained by: Healthy life expectancy" real,
    "Explained by: Freedom to make life choices" real,
    "Explained by: Generosity" real,
    "Explained by: Perceptions of corruption" real,
    "Dystopia + residual" real
);


ALTER TABLE public."2020" OWNER TO postgres;

--
-- Name: 2021; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."2021" (
    country character varying(50),
    "Regional indicator" character varying(50),
    "Ladder score" real,
    "Standard error of ladder score" real,
    upperwhisker real,
    lowerwhisker real,
    "Logged GDP per capita" real,
    "Social support" real,
    "Healthy life expectancy" real,
    "Freedom to make life choices" real,
    generosity real,
    "Perceptions of corruption" real,
    "Ladder score in Dystopia" real,
    "Explained by: Log GDP per capita" real,
    "Explained by: Social support" real,
    "Explained by: Healthy life expectancy" real,
    "Explained by: Freedom to make life choices" real,
    "Explained by: Generosity" real,
    "Explained by: Perceptions of corruption" real,
    "Dystopia + residual" real
);


ALTER TABLE public."2021" OWNER TO postgres;

--
-- Name: 2022; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."2022" (
    "RANK" integer,
    "Regional indicator" character varying(50),
    country character varying(50),
    "Happiness score" real,
    "Whisker-high" real,
    "Whisker-low" real,
    "Dystopia (1.83) + residual" real,
    "Explained by: GDP per capita" real,
    "Explained by: Social support" real,
    "Explained by: Healthy life expectancy" real,
    "Explained by: Freedom to make life choices" real,
    "Explained by: Generosity" real,
    "Explained by: Perceptions of corruption" real
);


ALTER TABLE public."2022" OWNER TO postgres;

--
-- Name: 2022_v00; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."2022_v00" (
    "RANK" integer,
    country character varying(50),
    "Happiness score" real,
    "Whisker-high" real,
    "Whisker-low" real,
    "Dystopia (1.83) + residual" real,
    "Explained by: GDP per capita" real,
    "Explained by: Social support" real,
    "Explained by: Healthy life expectancy" real,
    "Explained by: Freedom to make life choices" real,
    "Explained by: Generosity" real,
    "Explained by: Perceptions of corruption" real
);


ALTER TABLE public."2022_v00" OWNER TO postgres;

--
-- Data for Name: 2015; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."2015" (country, region, "Happiness Rank", "Happiness Score", "Standard Error", "Economy (GDP per Capita)", "Family", "Health (Life Expectancy)", freedom, "Trust (Government Corruption)", generosity, "Dystopia Residual") FROM stdin;
\.
COPY public."2015" (country, region, "Happiness Rank", "Happiness Score", "Standard Error", "Economy (GDP per Capita)", "Family", "Health (Life Expectancy)", freedom, "Trust (Government Corruption)", generosity, "Dystopia Residual") FROM '$$PATH$$/3619.dat';

--
-- Data for Name: 2016; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."2016" (country, region, "Happiness Rank", "Happiness Score", "Lower Confidence Interval", "Upper Confidence Interval", "Economy (GDP per Capita)", "Family", "Health (Life Expectancy)", freedom, "Trust (Government Corruption)", generosity, "Dystopia Residual") FROM stdin;
\.
COPY public."2016" (country, region, "Happiness Rank", "Happiness Score", "Lower Confidence Interval", "Upper Confidence Interval", "Economy (GDP per Capita)", "Family", "Health (Life Expectancy)", freedom, "Trust (Government Corruption)", generosity, "Dystopia Residual") FROM '$$PATH$$/3618.dat';

--
-- Data for Name: 2017; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."2017" (country, "Happiness.Rank", "Happiness.Score", "Whisker.high", "Whisker.low", "Economy..GDP.per.Capita.", "Family", "Health..Life.Expectancy.", freedom, generosity, "Trust..Government.Corruption.", "Dystopia.Residual") FROM stdin;
\.
COPY public."2017" (country, "Happiness.Rank", "Happiness.Score", "Whisker.high", "Whisker.low", "Economy..GDP.per.Capita.", "Family", "Health..Life.Expectancy.", freedom, generosity, "Trust..Government.Corruption.", "Dystopia.Residual") FROM '$$PATH$$/3617.dat';

--
-- Data for Name: 2018; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."2018" ("Overall rank", "Country or region", score, "GDP per capita", "Social support", "Healthy life expectancy", "Freedom to make life choices", generosity, "Perceptions of corruption") FROM stdin;
\.
COPY public."2018" ("Overall rank", "Country or region", score, "GDP per capita", "Social support", "Healthy life expectancy", "Freedom to make life choices", generosity, "Perceptions of corruption") FROM '$$PATH$$/3616.dat';

--
-- Data for Name: 2019; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."2019" ("Overall rank", country, score, "GDP per capita", "Social support", "Healthy life expectancy", "Freedom to make life choices", generosity, "Perceptions of corruption") FROM stdin;
\.
COPY public."2019" ("Overall rank", country, score, "GDP per capita", "Social support", "Healthy life expectancy", "Freedom to make life choices", generosity, "Perceptions of corruption") FROM '$$PATH$$/3615.dat';

--
-- Data for Name: 2020; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."2020" (country, "Regional indicator", "Ladder score", "Standard error of ladder score", upperwhisker, lowerwhisker, "Logged GDP per capita", "Social support", "Healthy life expectancy", "Freedom to make life choices", generosity, "Perceptions of corruption", "Ladder score in Dystopia", "Explained by: Log GDP per capita", "Explained by: Social support", "Explained by: Healthy life expectancy", "Explained by: Freedom to make life choices", "Explained by: Generosity", "Explained by: Perceptions of corruption", "Dystopia + residual") FROM stdin;
\.
COPY public."2020" (country, "Regional indicator", "Ladder score", "Standard error of ladder score", upperwhisker, lowerwhisker, "Logged GDP per capita", "Social support", "Healthy life expectancy", "Freedom to make life choices", generosity, "Perceptions of corruption", "Ladder score in Dystopia", "Explained by: Log GDP per capita", "Explained by: Social support", "Explained by: Healthy life expectancy", "Explained by: Freedom to make life choices", "Explained by: Generosity", "Explained by: Perceptions of corruption", "Dystopia + residual") FROM '$$PATH$$/3614.dat';

--
-- Data for Name: 2021; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."2021" (country, "Regional indicator", "Ladder score", "Standard error of ladder score", upperwhisker, lowerwhisker, "Logged GDP per capita", "Social support", "Healthy life expectancy", "Freedom to make life choices", generosity, "Perceptions of corruption", "Ladder score in Dystopia", "Explained by: Log GDP per capita", "Explained by: Social support", "Explained by: Healthy life expectancy", "Explained by: Freedom to make life choices", "Explained by: Generosity", "Explained by: Perceptions of corruption", "Dystopia + residual") FROM stdin;
\.
COPY public."2021" (country, "Regional indicator", "Ladder score", "Standard error of ladder score", upperwhisker, lowerwhisker, "Logged GDP per capita", "Social support", "Healthy life expectancy", "Freedom to make life choices", generosity, "Perceptions of corruption", "Ladder score in Dystopia", "Explained by: Log GDP per capita", "Explained by: Social support", "Explained by: Healthy life expectancy", "Explained by: Freedom to make life choices", "Explained by: Generosity", "Explained by: Perceptions of corruption", "Dystopia + residual") FROM '$$PATH$$/3613.dat';

--
-- Data for Name: 2022; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."2022" ("RANK", "Regional indicator", country, "Happiness score", "Whisker-high", "Whisker-low", "Dystopia (1.83) + residual", "Explained by: GDP per capita", "Explained by: Social support", "Explained by: Healthy life expectancy", "Explained by: Freedom to make life choices", "Explained by: Generosity", "Explained by: Perceptions of corruption") FROM stdin;
\.
COPY public."2022" ("RANK", "Regional indicator", country, "Happiness score", "Whisker-high", "Whisker-low", "Dystopia (1.83) + residual", "Explained by: GDP per capita", "Explained by: Social support", "Explained by: Healthy life expectancy", "Explained by: Freedom to make life choices", "Explained by: Generosity", "Explained by: Perceptions of corruption") FROM '$$PATH$$/3620.dat';

--
-- Data for Name: 2022_v00; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."2022_v00" ("RANK", country, "Happiness score", "Whisker-high", "Whisker-low", "Dystopia (1.83) + residual", "Explained by: GDP per capita", "Explained by: Social support", "Explained by: Healthy life expectancy", "Explained by: Freedom to make life choices", "Explained by: Generosity", "Explained by: Perceptions of corruption") FROM stdin;
\.
COPY public."2022_v00" ("RANK", country, "Happiness score", "Whisker-high", "Whisker-low", "Dystopia (1.83) + residual", "Explained by: GDP per capita", "Explained by: Social support", "Explained by: Healthy life expectancy", "Explained by: Freedom to make life choices", "Explained by: Generosity", "Explained by: Perceptions of corruption") FROM '$$PATH$$/3612.dat';

--
-- PostgreSQL database dump complete
--

